i=1
while i<=20:
    print(i)
    i=i+1
print("循环结束")