l=[]
while True:
    n=int(input("输入一些循环的整数："))
    if n==-1:
        break
    l+=[n]
print(l)
print(max(l))