begin=int(input("输入一个开始值："))
end=int(input("输入一个结束值："))
i=begin
while i<=end:
    print(i,end=" ")
    i=i+1
print()