from b import y
y()

def x():
    print("这是a.ｐｙ的ｘ函数")