l=[x**2 for x in range(1,101) if (x%2==1)]
print(l)