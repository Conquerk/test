num=input("请输入季度：")
num=int(num)
if num==1 : 
    print("1,2,3") 
elif num==2:
    print("4,5,6")
elif num==3:
    print("7,8,9")
elif num==4:
    print("10,11,12")
else:
    print("您输入错误")


     