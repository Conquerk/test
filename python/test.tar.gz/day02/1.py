print("hello")

x=100+200

print(x)