class dog:
    """此语句用来定义一个新的类型　dog"""
    pass

dog1=dog()    # 创建一个实例对象
print(id(dog1))
dog2=dog()
print(id(dog2))



lst1=list()     # 创建列表对象
print(id(lst1))
lst2=list()
print(id(lst2))
