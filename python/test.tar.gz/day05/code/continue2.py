# 跳过奇数　打印10　以内的偶数
for x in range(10):
    if x%2 ==1:
        continue
    print(x)