a=int(input("小时："))
b=int(input("分钟："))
c=int(input("秒："))
print(a*3600+b*60+c*1)


#total_second    总共的秒数
# second    秒