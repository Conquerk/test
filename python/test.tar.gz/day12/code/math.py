from math import pi,sqrt
x=float(input("输入圆的半径："))
print("圆的面积为：",pi*(x**2))

y=float(input("请输入圆的面积："))
r2=sqrt(y/pi)
print("半径为",r2)