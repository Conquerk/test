#file ：　ｍｙｐａｃｋ/menu.py
def show_menu():
    print("1.魂斗罗")
    print("2.超级玛丽")
    print("3.坦克大战")
    print("4.word")
    print("5.excel")