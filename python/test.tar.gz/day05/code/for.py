a=input("请输入字符串")
c=0   #计数变量
d=0
for b in a :
    if b=="a":
        c+=1
    if b==" ":
        d+=1
print("＇ａ＇的个数为：",c)
print("空格的个数为：",d)
    
    
