x=input("请输入一个字符串：")
y=x.replace(" ","")
print("原字符串为：",x,"长度为：",len(x))
print("处理后的字符串为：",y,"长度为：",len(y))