#return 语句的作用和用法
def say_hello():
    print("hello.world")
    print("hello,bejing")
    return 1+2
    print("hello,najing")

r=say_hello()  #调用
print(r)
print("程序结束")