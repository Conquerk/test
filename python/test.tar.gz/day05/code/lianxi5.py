for x in range(65,(65+26)):
        b=chr(x)
        print(b,end=" ")
for y in range(97,(97+26)):
        a=chr(y)
        print(a,end=" ")
print()