i=1
while i<=20:
    print(i,end=" ")
    if i%5==0:
        print()
    i+=1
print()