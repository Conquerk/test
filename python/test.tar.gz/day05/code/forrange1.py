for x in range(4,0):
    print(x)
#else:
    #print("循环结束的x值是：",x)
# 报错