x=input("输入一个字符串：")
y=x[1:-1]
print(y)