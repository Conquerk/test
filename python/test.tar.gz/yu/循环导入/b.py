#from a import x
def y():
    print("这是ｂ．ｐｙ的ｙ函数")