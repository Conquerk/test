class dog:
    """此语句用来定义一个新的类型　dog"""
    pass


print(dog)