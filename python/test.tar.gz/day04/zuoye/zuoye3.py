n=int(input("输入一个整数："))
x=1
while x<=n:
    print("*"*x)
    x+=1
