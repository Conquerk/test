Names=["中国移动","中国电信","中国联通"]
for t in enumerate(Names):
    print(t)
for t in enumerate(Names,101): 
    print(t)