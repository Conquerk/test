x=int(input("输入一个整数："))
y=int(input("输入一个整数："))
z=int(input("输入一个整数："))
l=[x,y,z]
print(max(l))
print(min(l))
print((sum(l)/3))