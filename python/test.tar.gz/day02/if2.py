x=input("任意输入一个数：")
x=int(x)
if x > 100 :
    print("大于100")
else:
    print("小于100")
if x > 0 :
    print("大于0")
else:
    print("小于0")

