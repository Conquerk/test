# 示例函数的定义与调用
def say_hello():
    print("hello.world")
    print("hello,bejing")
say_hello() #调用一次
say_hello() #调用两次
