import sys
#从标准输入文件中读取内容
#ｃｔｒｌ+ｄ 输入文件结束符
s=sys.stdin.readline()
print(s)
print("len(s)",len(s))

s=input("请输入")
print(s)