def mymax3(a,b,c):
    d=max(a,b,c)  #  z=a if a>b else b
    return d        # z=zif z>c else c
print(mymax3(100,300,200))  # return z
print(mymax3("abc","123","ABC"))