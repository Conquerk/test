#def myadd(x,y):
 #   return max(x,y)



myadd=lambda x,y:x if x>y else y
print(myadd(100,200))
print(myadd(200,300))