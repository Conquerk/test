#关键字传参
def mymin(a,b,c):
    print(a)
    print(b)
    print(c)
mymin(c=100,b=200,a=300)