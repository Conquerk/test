n=0
while n<10:
    print(n,end=" ")
    n+=0.5
print()