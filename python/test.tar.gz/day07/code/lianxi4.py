L=["tarena","xiaozhang","hello"]
d={s : len(s)for s in L }
print(d)