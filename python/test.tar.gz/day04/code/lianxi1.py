i=1
while i<=20:
    print(i,end=" ")
    i+=1
else:
    print("")