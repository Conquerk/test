print("hello")
print(1,2,3,4)
print(1,2,3,4,sep="#")