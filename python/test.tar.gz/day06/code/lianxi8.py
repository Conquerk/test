l=[x for x in range(1,101,3)]
print(l)