
a=input("请输入第一行：")
b=input("请输入第二行：")
c=input("请输入第三行：")
max_lean=len(a)
if len(b)>max_lean:
    max_lean=len(b)
if len(c)>max_lean:
    max_lean=len(c)
#(判断最大值)

