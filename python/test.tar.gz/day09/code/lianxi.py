def myadd(a,b,c=0,d=0):
    x=a+b+c+d
    return(x)
print(myadd(10,20))
print(myadd(100,200,300))
print(myadd(1,2,3,4))

