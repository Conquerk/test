def goodbey(l):
    for x in l:
        print("再见",x)
def hello(l):
    for x in l:
        print("你好",ｘ)
def fx(fn,l):
    fn(l)

fx(goodbey,["tom","jerry","spike"])
fx(hello,["tom","jerry","spike"])