def mysum(*args):
    x=sum(args)
    return x
print(mysum(1,2,3,4,5,6))
print(mysum())