i=1
n=int(input(""))
while i<=n:
    print("这是第",i,"行")
    i+=1
