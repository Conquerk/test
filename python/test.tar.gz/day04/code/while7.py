j=0
while j<10:
    i=1
    while i<=20:
        print(i,end=" ")
        i=i+1
    print()
    j+=1






#i=1
#while i<=20:
#    print(i,end=" ")
 #   i=i+1
#print()