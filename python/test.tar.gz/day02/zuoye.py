#x=int(input("x："))
#y=int(input("y："))
x=input("请输入第一个数：")
y=input("请输入第二个数：")
x=int(x)  #字符串转化为整数
y=int(y)
print("合为：",x+y)
print("积为：",x*y)
print("次方为：",x**y)