x=int(input("请输入一个整数"))
if 0<=x<=65535:
    print(chr(x))