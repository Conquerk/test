for x in range(1,21):
    print(x,end=" ")
    if x%5==0:
        print()