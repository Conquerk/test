def say_hello():
    print("hello.world")
    print("hello,bejing")
    print("hello,najing")
    #此处相当于有　return none
r=say_hello()  #调用
print(r)
print("程序结束")