num=input("输出一个数：")
num=int(num)
num=input("输出一个数：")
num=int(num)
num=num if num>0 else -num
print("绝对值是",num)