import time

print("这是第一条语句")
time.sleep(5)
print("这是第二条语句")