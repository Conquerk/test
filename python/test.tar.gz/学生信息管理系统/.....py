x=int(input("请输入一个整数："))
if x==1:
    a=int(input("输入一个新的数："))
    print(a)
if x==2:
    b=input("输入一个新的年龄：")
    print(b)
    