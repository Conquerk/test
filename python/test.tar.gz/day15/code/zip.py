l=["sss","sssa","aaa"]
l1=["1","2","3"]
l3=zip(l,l1)
l4=dict(zip(l,l1))
print(l4)
for x in zip(l,l1):
    print(x)




