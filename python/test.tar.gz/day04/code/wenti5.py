begin=int(input("输入一个开始值："))
end=int(input("输入一个结束值："))
s=0
while begin<=end:
    s+=begin
    begin+=1
print(s)




