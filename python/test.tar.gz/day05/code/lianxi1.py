for x in range(1,21):
    print(x,end=" ")
print()