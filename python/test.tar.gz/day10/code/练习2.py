fx=lambda n : (n**2+1)%5==0
print(fx(3))
print(fx(4))