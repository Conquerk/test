list1=[1001,1002,1003,1004]
list2=["tom","jerry","spike","tyke"]
d={list2[i]:list1[i]for i in range(len(list1))}
print(d)
