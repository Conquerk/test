#Mypack/games/__init__.py

#此列表将在ｆｒｏｍ mypack.games import *
# 只导入　contra 和ｔａｎｋｓ
__all__=['contra','tanks']

print("Mypack/games/的子包被导入")