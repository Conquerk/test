for x in range(100):
    if x*(x+1)% 11==8:
        print(x)
