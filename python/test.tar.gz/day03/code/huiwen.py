x=input("输入一个字符串：")
y=x[::-1]
if x==y:
    print("这个字符串回文")
else:
    print("这个字符串不回文")