l=[]
while True:
    x=int(input("输入整数"))
    if x<0:
        print(l)
    if x<0:
        break
    l+=[x]