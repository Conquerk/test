# import random   # (生成随机数)


b=bytes(range(256))
print(b)
b1=bytes(100)
print(b1)