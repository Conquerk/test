s=0
x=1
while x<100:
    s+=(1/x)
    x+=2
print(s)
