name=input("请您输入名字：")
print("您刚才输入的是：",name)
