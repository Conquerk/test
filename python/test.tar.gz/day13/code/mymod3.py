#示例隐藏属性：
def f():
    pass
def _f():
    pass
def __f():
    pass
def a():
    pass
name1="aaa"
_name2="bbbb"
