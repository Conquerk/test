f=open("infos.txt")
for x in f:
    print("姓名:",x[0])