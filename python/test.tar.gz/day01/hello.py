
print("hello world")
print("你好")
import random
# print random.randint(1,100)