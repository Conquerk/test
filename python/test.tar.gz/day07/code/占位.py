name="xiaohong"
age=18
phone=119
ip="152.145.10.3"
#这个人的姓名（），年龄（）.....

print("这个人的姓名{}年龄{}电话{}ｉp{}"
.format("xiaohong",18,119,"152.145.10.3"))