s="100,200,300,500,800"
l=s.split(',')
print(l)
l1=[] 
for x in l:
    i=int(x)
    l1.append(i)
print(l1)
