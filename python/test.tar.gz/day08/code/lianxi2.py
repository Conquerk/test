def myadd2(x,y):
    z=x+y
    return(z)
a=int(input("请输入第一个数"))
b=int(input("请输入第二个数") )  
print("你输入的这两个数的和是：",myadd2(a,b))

