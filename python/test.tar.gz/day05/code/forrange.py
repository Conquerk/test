i=6
    #　ｒａｎｇｅ函数只调用一次
for x in range (1,i):
    #此ｐｒｉｎｔ函数会执行5次
    print("x=",x,"i=",i)
    i-=1
