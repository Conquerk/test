import math
s=0
for x in range(1,21):
    y=math.factorial(x)
    s+=y
print(s)