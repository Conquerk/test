import mymod
mymod.mysum(100)
from mymod import name2
print(name2)
import os
print(os.name)
print(__name__)