#输入一个学生成绩　0-100　　判断是否为合法成绩  打印不合法成绩

x=int(input("请输入成绩"))

if 0<=x<=100:
    pass#print("成绩合法")
else:
    print("...")

