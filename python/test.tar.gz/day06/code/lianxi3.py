s="hello"
y=s.split()
print(y)

x=" ".join(s)
print(x)