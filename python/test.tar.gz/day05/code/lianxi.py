s='ABCDE'
for ch in s:
    print("ch--->",ch)
else :
    print("遍历结束")