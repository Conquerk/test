x=input("输入一个字符串：")
if x != None:
    print(ord(x[0]))