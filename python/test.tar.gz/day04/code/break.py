i=1
while i<=6:
    print("本次循环结束：",i)
    if i==3:
        break# 结束当前ｗｈｉｌｅ语句的执行
    print("本次循环结束：",i)
    i=i+1
else:
    print("我是ｅｌｓｅ语句离得ｐｒｉｎｔ")
print("循环结束")