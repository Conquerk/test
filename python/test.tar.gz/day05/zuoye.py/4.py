for x in range(100,1000):
    bai=x//100#百位
    shi=x%100//10#十位
    ge=x%10#个位
    if bai**3+shi**3+ge**3==x:
        print(x)

for bai in range(1,10):
    for shi in range(10):
        for ge in range(10):
            print(bai,shi,ge)
            x=bai*(10**2)+shi*(10)+ge
            if bai**3+shi**3+ge**3==x:
                print(x)
