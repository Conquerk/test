#输入一个数判断这个数为　奇数　还是偶数
x=int(input("请输入一个整数："))
if x % 2 == 0:
    print("是偶数")
else:
    print("是奇数")
    