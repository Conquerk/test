import mypack.menu 
#引入　包里的模块
mypack.menu.show_menu() 
#调用包内模块的ｓｈｏｗ＿ｍｅｎｕ函数


# 导入　ｍｙｐａｃｋ离得ｇａｎｍｅｓ文件夹内的　　模块
import mypack.games.contra
mypack.games.contra.play()
#调用     坦克大战
mypack.games.contra.game_over()

