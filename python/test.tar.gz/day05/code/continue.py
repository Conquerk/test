for x in range(5):
    if x==2:
        continue
    print(x)