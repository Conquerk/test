#特殊字符　转义字符的表示
print("ABCD\rab")
print("ABCD\tab")
print("ABCD\bab")