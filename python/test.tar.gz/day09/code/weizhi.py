#示例　　位置传参
def mymin(a,b,c):
    print(a)
    print(b)
    print(c)
mymin(1,2,3)
mymin(4,5,6)
