#打印20　行　ｈｅｌｌｏ
i=1
while i<=5:
    print("hello")
    i=i+1
else:
    print("这是ｗｈｉｌｅ里的ｅｌｓｅ子句里的语句")
    print(i)
print("循环结束")
