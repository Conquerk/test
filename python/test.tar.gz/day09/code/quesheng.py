#示例函数的缺省参数
def info(name,age=1,address="不祥"):
    print(name,"今年",age,"岁","家庭住址",address)

info("xxxx",21,"xxx")
info("李四")