j=1     # 代表行数
while j<=10:
    i=1    #代表打印的数
    while i<=20:
        print(i,end=' ')
        if i==10:
            break
        i+=1
    print()#打印一行完成
    j+=1