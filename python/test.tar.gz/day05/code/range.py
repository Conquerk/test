for x in range(4):
    print(x)
print("         ｆｅｎｇｅｆｕ")
for y in range(3,5):
    print(y)