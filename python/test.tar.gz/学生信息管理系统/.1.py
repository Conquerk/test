d={"name":"张三","age":18,"score":55}
d2={"name":"关羽"}
d.update(d2)
print(d)