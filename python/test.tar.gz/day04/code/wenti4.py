i=1
s=0  #次变量用来记录加后的结果
while i<=100:
    #print(i)
    s=s+i
    i+=1
print(s)