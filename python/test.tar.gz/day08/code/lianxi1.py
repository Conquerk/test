def myadd(x,y):
    z=x+y  
    #(创建局变量)
    print("和为：",z)
myadd(100,200)
myadd("ABC","123")