import sys

sys.stdout.write("你好\n")
print("hello")   