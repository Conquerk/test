a=int(input("输入一个整数："))
j=1     # 代表行数
while j<=a:
    i=1    #代表打印的数
    while i<=a:
        print(i,end=' ')
        i+=1
    print()#打印一行完成
    j+=1
    
    
